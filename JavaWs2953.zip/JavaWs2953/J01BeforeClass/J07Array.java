public class J07Array
{
    public static void main(String[] args)
    {
        int[] array = new int [6];
        for (int i=0;i<array.length;i++)
        {
            if(array[i]%2==0)
            {
               System.out.print(array[i]+" ");     
            }

        }
       
       
   
   
   
    }

}