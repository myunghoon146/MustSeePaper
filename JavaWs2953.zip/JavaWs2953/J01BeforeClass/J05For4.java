public class J05For4{

        public static void main(String[] args){

            for(int i=10;i>0;i=i-1){

                System.out.print(i+ " ");


            }
            System.out.println("어휴 끝....");




        }

}