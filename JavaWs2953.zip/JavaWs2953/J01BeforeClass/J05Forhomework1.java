import java.util.Scanner;
public class J05Forhomework1{

    public static void main (String[] args){
        int num1;
        Scanner sc = new Scanner(System.in);
        System.out.println("Input Number: ");
        num1 = sc.nextInt();
        sc.close();

        for (int i=1;i<11;i=i+1){

            System.out.println(i + ",");

        }

        if(num1%2==0){
            
            System.out.println("Even Number!!!!");

                    }

    }


}