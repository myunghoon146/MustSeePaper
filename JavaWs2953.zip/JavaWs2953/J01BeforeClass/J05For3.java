public class J05For3{

        public static void main(String[] args){

        int cnt = 10;   
        for (int i=0;i<10;i=i+1){

            System.out.print(i+ "  ");
            //cnt = cnt-1;
                                }        

          System.out.println("어휴 끝....");                      



                                                }

                    }