import java.util.Scanner;
public class J05For4Practice {

    public static void main(String[] args){

        Scanner sc = new Scanner(System.in);
        char c;
        System.out.print("Upper Char Input : ");
        
        c = sc.next().charAt(0);

        for(char i = 'A';i<=c;i=i++){


            System.out.print(i + " ");

        }







    }



                                }