public class J06ForForexample1{
        public static void main(String[] args){
            int cnt=1;
            for(int i=0;i<5;i++){
            
                for(int j=0;j<=i;j++)
                {
                    System.out.printf("%2d",cnt);
                    cnt=cnt+1;

                }

                                }

                     System.out.println();                           }

                                }