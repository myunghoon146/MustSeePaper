public class J07Arrayhomework2
{

}