public class J06ForFor{
        public static void main(String[] args){

            for(int i=0;i<5;i++){

                for(int j=0;j<5;j++){

                   // System.out.print(j+1+(i*5)+" ");
                   System.out.printf("%2d",j+1+(i*5));
                }

                 System.out.println();               }

                System.out.println("======================="); 
            int cnt =1;
        for(int i=0;i<5;i++){
            for(int j=0;j<5;j++){

                System.out.printf("%2d", cnt);
                cnt=cnt+1;
                                }
                          }                             }

                        }