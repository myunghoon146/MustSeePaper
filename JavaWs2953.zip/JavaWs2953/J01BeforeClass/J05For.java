package J01BeforeClass;
public class J05For{

    public static void main(String[] args){
    
        //스쿼트 10번 시키기. 스쿼트 할 때마다 "스퀏!" 출력
        
        int cnt; //몇개 했는지 세는 놈
        for (cnt=0;cnt<10;cnt=cnt++);

        System.out.println("Squat:" +cnt);



        
    
                                        }
    
    



    }