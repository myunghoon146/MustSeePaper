import java.util.Scanner;
public class J10MultyArray
{
    public static void main(String[] args)
    {
        int[][][] Students = new int[2][2][3];
        for(int i=0;i<Students.length; i++)
        {
            System.out.printf("[%d번째 학생]\n", i+1);
            for(int j=0;j<Students[i].length;j++)
            {
                System.out.printf("<%d 학기>\n",j+1);

                for(int k=0;k<Students[i][j].length;k++)
                {
                    System.out.printf("%d번째 성적 입력 : ", k+1);
                    Scanner sc = new Scanner(System.in);
                    int temp = sc.nextInt(); // 숫자 입력받음.

                    // 배열에 점수 저장
                    Students[i][j][k]=temp;                    
                }
            }
        }
   
            //향상된 For문 이용해서 평균들을 구해보자.

            for(int[][] i : Students)
            {
                double totalAverage =0;
                //==================================
                for(int[] j : i)
                {
                    // j는 학기를 의미함
                    double average=0;
                    int sum=0;
                    for(int k : j)
                    {
                        sum=sum+k;
                    }
                    average = sum/3.0;
                    System.out.println("학기평균 :" + average);
                    totalAverage = totalAverage + average;
                }

                //====================================

                System.out.printf("평균 : %.f",totalAverage);
            }


            //향상된 For문이 아닌 방식으로 다시 풀어보기.
   
        
   
    }
}