import java.util.Scanner;
public class J05Forhomework2{

        public static void main(String[] args){
           
            int num1;     
           Scanner sc = new Scanner(System.in); 
           System.out.println("Input Value: ");
           num1 = sc.nextInt();
           sc.close();

           for (int i=1; i<11;i=i+2){
                    System.out.println(i+ ",");
           }

           if(num1%2==1){

                System.out.println("Odd Number!!");

                        }


                                                }



                            }