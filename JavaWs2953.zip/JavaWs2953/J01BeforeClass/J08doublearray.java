public class J08doublearray
{
    //메소드 만들기
    public static void Enter()
    {
        System.out.println("\n======================");
    }
    public static void P(int asdflower)
    {
        System.out.print(asdflower + " ");
    }
    public static void main(String[] args)
    {
        int[][] ary2={{1,2,3},{4,5,6},{7,8,9},{10,11,12}};

        String str ="Hello";
        String[] str2 = {"Hello","World"};
        System.out.println(str.charAt(0));
        System.out.println(str2[1]);
        System.out.println(str2[0].charAt(1));
       
        // 2차원 배열 전체 출력하기.
        Enter();
       // int[][] ary2={{1,2,3},{4,5,6},{7,8,9},{10,11,12}};
        for(int i=0;i<ary2.length;i++)
        {
            for(int j=0; j<ary2[i].length; j++)
            {
                System.out.print(ary2[i][j]+ " ");
            }
        }
        Enter();
        for (int i :ary2[0])
        {
            System.out.print(i+ " ");
        }
        for (int i[] : ary2)
        {
            for(int j:i)
            {
                P(j);
            }
        }
        Enter();

    }
}