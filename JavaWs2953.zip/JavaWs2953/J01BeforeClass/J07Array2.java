public class J07Array2
{
    public static void main(String[] args)
    {
        int[] array = {1,2,3,4,5,6,7,8,9,10};
        for(int i=0;i<array.length;i++)
        {
        System.out.println(array[i]+ " ");
        }
        System.out.println("\n=======================");
        
        for(int i: array)
        {
            System.out.print(i + "");

        }
        System.out.println("\n==================");


        for(int i=0;i<array.length;i++)
        {
            array[i]= array[i]*2;
            System.out.print(array[i]+"");
        }
        System.out.println("\n===================");
        for(int i : array)
        {
            i=i*2;
            System.out.print(i+ " ");


        }
    }
}