import java.util.Scanner;
public class J05For8{

    public static void main(String[] args){

    int value;
    Scanner sc = new Scanner(System.in);
    System.out.println("Input Number: ");
    value = sc.nextInt();
    sc.close();
    
    for (int i=1; i<=value; i=i+1)
    {

        System.out.print(i+ ",");

    }

                                            }


                    }