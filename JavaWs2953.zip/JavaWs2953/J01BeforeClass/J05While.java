import java.util.Scanner;
public class J05While{

    public static void main(String[] args){

        Scanner sc = new Scanner(System.in);
        int input;
        while(true){

            System.out.print("Input(-1 Exit): ");
            input = sc.nextInt();

            if(input==-1){
                System.out.println("-1 Detected. Exit!");
                break;
            }
        }
        System.out.println("While Exit. Goodbye");


                                            }


                    }