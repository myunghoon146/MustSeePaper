public class J05For7{

        public static void main(String[] args){

            for (int i=1;i<11;i=i+1){

                System.out.print(i + ",");
                
            }


                                                }


                    }