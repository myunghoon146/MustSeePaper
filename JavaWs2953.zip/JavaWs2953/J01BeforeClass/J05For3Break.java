import java.util.Scanner;
public class J05For3Break {

    public static void main(String[] args){

        //break와 continue에 대한 학습
        //break -> 만나는 순간 가장 가까운 반복문 탈출(와장창)
        //continue -> 만나는 순간 바로 증감식 위치로 이동
        
        //1. 1~100 출력하되, 입력한 숫자가 나오면 Break + 누적합
        System.out.println("==== Quiz1 ====");
        int quiz1Value;
        Scanner sc = new Scanner(System.in);
        System.out.print("Break Number :");
        quiz1Value = sc.nextInt();
        for(int i=1;i<=100;i=i+1){
            System.out.print(i+ "");
            if(i==quiz1Value){

                break;

            }
           else {

            
            System.out.print(i + "");
           } 
        }
        //2. 1~100 출력하되, 입력한 숫자의 배수들은 패스 + 누적합
        System.out.println("====Quiz2 ====");
        int quiz2Value;
        System.out.print("Continue Number : ");
        quiz2Value = sc.nextInt();
        sc.close();
        int quiz2Sum=0;


        for (int i=1;i<=100;i=i+1){

            if(i%quiz2Value == 0){

                   continue; 

            }
            System.out.print(i+ "");
            quiz2Sum = quiz2Sum +i;
        }
        System.out.println("\nSum :" +quiz2Sum);



    }


}