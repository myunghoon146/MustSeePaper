package J01BeforeClass;
public class J05For2{

        public static void main(String[] args){
        
        int num=0;
        for (num=0; num<7; num++){

            System.out.print("이얍:" +num);

        }    

        

                                                }


                    }