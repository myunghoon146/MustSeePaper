package J02AfterClass.Quiz3;

public class Main 
{
    public static void main(String[] args)
    {
        AlertSystem alert = new DigitalAlert(5);
        alert.AlertPlay();
        
        alert = new AnalogAlert(3);
        alert.ChangeTime(5);
        alert.AlertPlay();
    }    
}
