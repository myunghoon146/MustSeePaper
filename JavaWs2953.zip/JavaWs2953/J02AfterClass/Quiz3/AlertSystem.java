package J02AfterClass.Quiz3;

public interface AlertSystem 
{
    public static final int alertTime3 =3;
    public static final int alertTime5 =5;
    public static final int alertTime7 =7;
    
    public abstract void AlertPlay();
    public abstract void ChangeTime();
    public abstract void ChangeTime(int time);
}
