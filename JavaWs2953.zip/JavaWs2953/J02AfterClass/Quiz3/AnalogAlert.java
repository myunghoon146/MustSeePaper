package J02AfterClass.Quiz3;

public class AnalogAlert implements AlertSystem
{
    int currentAlertTime;

    public AnalogAlert(int time)
    {
        
        this.ChangeTime();

    }

    @Override
    public void AlertPlay() 
    {
       System.out.println("rrrr");
    }

    @Override
    public void ChangeTime() 
    {
        System.out.println(alertTime7);
    }

    @Override
    public void ChangeTime(int time) 
    {
        System.out.println(alertTime3);
    }
    
}
