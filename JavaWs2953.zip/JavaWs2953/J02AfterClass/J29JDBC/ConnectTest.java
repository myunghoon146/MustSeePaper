package J02AfterClass.J29JDBC;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ConnectTest 
{
    public static void main(String[] args) 
    {
        String url = "jdbc:mysql://localhost:3306/JavaTest";
        String user = "root";
        String password = "1234";
        
        //연결 객체 연동하기
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection(url, user, password);
            System.out.println("Connect Success");

            String sql = "Select * From UserInfo";
            // SQL을 실행하기 위해서는?
            // Statement를 통해서 DB까지 갔다올 놈을 만듬.(1회용)
            // ResultSet으로 Statement가 가져온 결과를 담아야함.

            Statement stat = conn.createStatement();
            ResultSet rs = stat.executeQuery(sql);
            stat.executeQuery(sql);

            while(rs.next())
            {
                // 커서를 다음줄로 변경
                System.out.print(rs.getString("userName"));
                System.out.print(rs.getString("userAge"));
            }

            rs.close(); stat.close(); conn.close();
        } catch (ClassNotFoundException e) {
            System.out.println("드라이버 로드 실패");
        } catch (SQLException e) {
            System.out.println("SQL 오류");
            System.out.println(e.getMessage());
        }


    }    
}
