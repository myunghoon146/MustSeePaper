package J02AfterClass.J29JDBC;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ItemInfoSelect
{
    public static void main(String[] args)
    {
        String url = "jdbc:mysql://localhost:3306/JavaTest";
        String user = "root";
        String password = "1234";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection(url, user, password);
            System.out.println("Connect Success");

            String sql = "Select * From ItemInfo";
            Statement stat = conn.createStatement();
            ResultSet rs = stat.executeQuery(sql);

            while(rs.next())
            {
                System.out.println(rs.getString("itemName"));
                System.out.println(rs.getString("itemCategory"));
            }

            rs.close();
            stat.close();
            conn.close();

        } catch (ClassNotFoundException e) 
        {
            System.out.println("드라이버 로드 실패");    
            
            System.out.println(e.getMessage());
        } catch (SQLException e) {
            System.out.println("SQL 오류");
            System.out.println(e.getMessage());
        }

    }    
}
