package J02AfterClass.J26Lambda;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import J02AfterClass.U;

interface Test1
{
    
    int Result(int number);

}

interface Util{void Print(int number);}

interface Test2
{
    int Result(int x, int y);
}

interface Test3{int Result(List<Integer> list);}


public class Main 
{
    public static void main(String[] args) 
    {
        // 람다식 연습
        // 반드시 함수형 인터페이스
        // Test1 구현

        Test1 t1 = (x) -> {

            int result = x*10;
            return result;

        };

        System.out.println(t1.Result(10));

        // Util u -> 숫자 넣으면 출력

        Util u = x -> System.out.println(x);
        u.Print(t1.Result(20));


        // 숫자 두개 입력받아서, 그거 두개 더한 후 출력하고 리턴
        // interface Test2 메서드 이름 Result
        // Test2 t2 =

        Test2 t2 =(x,y) -> {

            int temp = x+y;
            
            
        };

        List<Integer> list = new ArrayList<>();

        Random rand = new Random();
        for (int i=0;i<10;i++)
        {
            list.add(rand.nextInt(10));
        }
            
        
    }    
}
