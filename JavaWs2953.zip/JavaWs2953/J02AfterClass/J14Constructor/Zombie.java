package J02AfterClass.J14Constructor;

import java.util.Random;

public class Zombie 
{
    String name;
    int hp;
    static int number = 1;
    
    public Zombie()
    {
        this.name = "Zomebie"+ number++;
        Random rand = new Random();
        this.hp = rand.nextInt(21)+40;
    }

    public void Interaction()
    {
        System.out.println("ohhhh......" +this.name);

    }
    public void Attack(Player p)
    {
        
        System.out.println("Why not Avoid...");

    }
    public void Attacked(int attackPower)
    {
        this.hp -= attackPower;
        if(this.hp<=0)
        {
            System.out.println(this.name+"Died");
        }
    }
}
