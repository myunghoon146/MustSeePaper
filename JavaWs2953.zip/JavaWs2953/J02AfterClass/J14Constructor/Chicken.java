package J02AfterClass.J14Constructor;

public class Chicken 
{

    int times;
    String chickenName;
    int price;

    public Chicken(int times,String chickenName, int price)
    {
        this.times=times;
        this.chickenName=chickenName;
        this.price=price;
        this.PrintValue();
    }

    public Chicken(int times,String chickenName)
    {
        this.times=times;
        this.chickenName = chickenName;
        this.price=15000;
        this.PrintValue();
        System.out.println("price 15000 Setting");
    }

    public Chicken(int times,int price)
    {
        this.times=2;
        this.chickenName="Temp";
        this.price=35000;
        this.PrintValue();
    }

    public void PrintValue()
    {
        System.out.println("times:" +times);
        System.out.println("chickenName : " +chickenName);
        System.out.println("price:" + price);
        System.out.println("=================================");

    }

  

}
