package J02AfterClass.J14Constructor;

public class Test 
{
   
   
    int value1;
    int value2;
    String value3;
    public Test (int v1,int v2, String v3)
    {
        this.value1=v1;
        this.value2=v2;
        this.value3=v3;

        System.out.println("매개변수 생성자");
    }

    public Test()
    {
        System.out.println("기본 생성자");
    }
}    
