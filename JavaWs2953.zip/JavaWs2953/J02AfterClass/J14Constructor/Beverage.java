package J02AfterClass.J14Constructor;
import java.util.Scanner;
public class Beverage 
{
    int size;
    String[] beverage; 
    int[] price;    

    public Beverage(int size)
    {
        this.size=size;
        beverage = new String[size];
        price = new int[size];
        Scanner sc = new Scanner(System.in);
        for(int i=0;i<size;i++)
        {
            System.out.print("Input BeverageName :");
            String inputS=sc.nextLine();
            beverage[i] = inputS;
            System.out.print("Input Price : ");
            int inputP = sc.nextInt();
            price[i] = inputP;
        }
        sc.close();
    }

    public void Show()
    {
        for(int i=0;i<this.size;i++)
        {
            System.out.printf("%d: %s - %d\n", i, beverage[i],price[i]);
        }
    }
    public void Order(int index)
    {
        System.out.printf("%s Enjoy Your Drink!!!");
    }
}
