package J02AfterClass.J14Constructor;

public class Main 
{

    public static void main(String[] args)
    {
    

     //  Test t2 = new Test(10,20,"Hello");


     //  Chicken c1 = new Chicken(5,"Gubne",7800);
     //  Chicken c2 = new Chicken(8,"Jadam",2400);
     //  Chicken c3 = new Chicken(6,98000);

       //Beverage drink = new Beverage(5);
       //drink.Show();
       //drink.Order(1);

      // Player p1 = new Player();
      // p1.Introduce("Irene",500);

        Zombie z1 = new Zombie();
        z1.Interaction();
        

    }


    
}
