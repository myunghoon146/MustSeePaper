package J02AfterClass.J14Constructor;
public class Player
{

}