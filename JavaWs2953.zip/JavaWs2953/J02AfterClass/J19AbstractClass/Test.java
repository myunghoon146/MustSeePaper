package J02AfterClass.J19AbstractClass;

public class Test extends TestAbstract implements TestInterface
{

    // 필드

    // 생성자
    public Test()
    {
        super();
    }
    public Test(int value1, int value2)
    {
        super(value1,value2);
    }
    // 메서드

    @Override
    public void Test2() 
    {
        System.out.println(value3);
    }
    @Override
    public void Test3() 
    {
        System.out.println("Test 3");
    }

    public void TestSelf()
    {
        System.out.println("Self Method");
    }

}
