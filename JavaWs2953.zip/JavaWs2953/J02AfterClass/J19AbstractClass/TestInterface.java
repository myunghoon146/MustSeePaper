package J02AfterClass.J19AbstractClass;

public interface TestInterface 
{
    public abstract void Test3();
        
}
