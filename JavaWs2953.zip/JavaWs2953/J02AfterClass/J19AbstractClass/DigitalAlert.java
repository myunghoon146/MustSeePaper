package J02AfterClass.J19AbstractClass;
import java.awt.Toolkit;
public class DigitalAlert extends AlertSystem
{
    int currentAlertTime;

    public DigitalAlert(int time)
    {
        
        this.ChangeTime();

    }
    @Override
    public void AlertPlay() 
    {
       Toolkit.getDefaultToolkit().beep();
    }

    @Override
    public void ChangeTime() 
    {
        System.out.println(alertTime5);
    }

    @Override
    public void ChangeTime(int time) 
    {
        System.out.println(alertTime3);
    }
    
}
