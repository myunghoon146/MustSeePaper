package J02AfterClass.J19AbstractClass;

abstract public class TestAbstract 
{
    //필드
    public int value1;
    private int value2;
    public static final int value3=30;
    //생성자
    public TestAbstract()
    {
        this.value1=10;
        this.value2=20;
    }
    public TestAbstract(int value1, int value2)
    {
        this.value1 = value1;
        this.value2= value2;
    }
    //메소드
    public void Test1()
    {
        System.out.println(value1 + "," + value2);

    }
    public abstract void Test2();
}
