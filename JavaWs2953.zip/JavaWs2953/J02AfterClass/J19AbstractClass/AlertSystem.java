package J02AfterClass.J19AbstractClass;

abstract public class AlertSystem 
{
    public static final int alertTime3 =3;
    public static final int alertTime5 =5;
    public static final int alertTime7 =7;
    int currentAlertTime;
    
    abstract void AlertPlay();
    abstract void ChangeTime();
    abstract void ChangeTime(int time);
}
