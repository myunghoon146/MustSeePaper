package J02AfterClass.J19AbstractClass;

public class Main 
{   
    public static void main(String[] args)
    {
     TestInterface ta = new Test();
    
     ta.Test3();
     
     
    }
}
