package J02AfterClass.J25MVC;

import java.util.Scanner;

public class View {
    //필드
    Scanner sc = new Scanner(System.in);
    Controller con;
    //생성자
    //메서드
    public void Enter(){
        System.out.println("Welcome");
    }
    public void Input(){
        System.out.print("Num1 : ");
        int temp1 = sc.nextInt();
        System.out.print("Num2 : ");
        int temp2 = sc.nextInt();

        // Controller에게 입력 끝났다고 해야 함.
        // Controller의 메소드를 호출 -> 다음시간
        // MVC 간단하게 끝내고.. 람다식 -> 쓰레드
        if( con == null) // Controller를 지금 내가 모르고 있다면?
        {
            // Controller에게 객체를 달라고 해야 함.
            con = Controller.Init();
        }

        System.out.println(con.CalcPlus(temp1, temp2));
    }

    
}
