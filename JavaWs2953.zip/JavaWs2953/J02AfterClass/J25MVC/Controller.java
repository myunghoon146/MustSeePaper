package J02AfterClass.J25MVC;

public class Controller {
    // 필드
    private View view;
    private Model model;
    private static Controller self;

    // 생성자
    public Controller(){
        this.view = new View();
        this.model = new Model();
        if(self == null)
        {
        self=this;
        }
    }
    
    // 메소드
    // 숫자 두개 넘겨받아서, Model PlusNum 대신 실행, 값을 받아와서 다시 전달
    int CalcPlus(int n1, int n2){
        return model.PlusNum(n1, n2);
    }

    static Controller Init() {
        if(self==null)self = new Controller();
        return self;
    }
    
    

}
