package J02AfterClass.J25MVC;

public class Model {
    //필드
    int num1, num2;
    //생성자
    public Model(){
        num1=0;
        num2=0;
    }
    //메소드
    public int GetNum1(){
        return num1;
    }
    public int GetNum2(){
        return num2;
    }
    public void SetNum1(int num){
        this.num1 = num;
    }
    public void SetNum2(int num){
        this.num2 = num;
    }
    public int PlusNum(int n1,int n2){
        this.num1 = n1;
        this.num2 = n2;
        return n1+n2;
    }
    public int PlusNum(){
        return this.num1+this.num2;
    }

}
