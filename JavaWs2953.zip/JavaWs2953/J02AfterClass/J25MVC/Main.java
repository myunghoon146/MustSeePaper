package J02AfterClass.J25MVC;

public class Main 
{
    public static void main(String[] args) 
    {
        Controller con = new Controller();
        con.view.Input();    
    }    
}
