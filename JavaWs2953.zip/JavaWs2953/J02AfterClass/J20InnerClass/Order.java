package J02AfterClass.J20InnerClass;

public class Order 
{   
    private String customerName;
    private Item[] items;
    private Item[] shoppingCart;
    private int itemCount;
    private int shoppingCount;
    private int maxItem=10;
    

    public Order(String customerName)
    {
        this.customerName=customerName;
        this.itemCount=0;
        this.items = new Item[maxItem];
        this.shoppingCount = 0;
        this.shoppingCart = new Item[maxItem];

    } 
    public void AddCart(int itemNumber)
        {
            shoppingCart[shoppingCount++] = items[itemNumber-1];

        }

    public class Item
    {
        private String itemName;
        private int price;
        public Item(String itemName, int price)
        {
            this.itemName=itemName;
            this.price=price;
        }
        public void SetPrice(int price)
        {
            this.price=price;

        }
        
        public void ShowItemList()
        {
            for(int i=0;i<itemCount;i++)
            {   System.out.print("[" + (i+1)+"]");
                items[i].GetItemInfo();
            }
        }

        public void AddItem(String itemName, int price)
        {
            items[itemCount++] = new Item(itemName,price);
            System.out.println("[NEW] New Item Add!");
           
        }
        public void GetItemInfo()
        {
            System.out.println(itemName+','+price);
        }
        
    }
    
}
