package J02AfterClass.J20InnerClass;

public class Outer 
{
    public int value1;
    public Inner i;

    public Outer()
    {
        this.value1=10;
        i = new Inner();
        i.value2=20;
    }

    public void Test1()
    {
        System.out.println(value1);
    }

    public void Test2()
    {
        //i
        i.Test3();
    }
    public class Inner 
{
    int value2;    
    public void Test3()
    {
        System.out.println(value2);
    }
}

}   
