package J02AfterClass.J20InnerClass;

public class Human 
{
    private String leftArm;
    private String rightArm;

    public Human(String leftArm, String rightArm)
    {
        this.leftArm = leftArm;
        this.rightArm=rightArm;

    }

    public void Information()
    {
        System.out.println("Left Arm: " +leftArm);
        System.out.println("Right Arm: " +rightArm);
        System.out.println("Left Arm is turning around.");
        System.out.println("Right Arm is not moving");

    }

    public class LeftArm
    {
        String t;
        public LeftArm(String t)
        {
            System.out.println("New Tool: Scissor");

        }

        public void Information()
        {
            System.out.println("t.name: Tomika Scissor" +t);
        }

        public void UseTool()
        {
            System.out.println("Use Tool: Cutting paper ");
        }

    public class RightArm
    {
        String t;
        public RightArm(String t)
        {
            System.out.println("New tool: CD-ROM");           
        }

        public void Information()
        {
            System.out.println("t.name: Elisha CD-ROM");
        }

        public void UseTool()
        {
            System.out.println("UseTool: Turning On Music and Program");
        }
    }
    }
   

}
