package J02AfterClass.J20InnerClass;

public class Main 
{
    public static void main(String[] args) 
    {
        // -- 실습문제 1번 실행
        Order ord = new Order("MYC");
        
    }
    

    
    
    
    

    
    

}
