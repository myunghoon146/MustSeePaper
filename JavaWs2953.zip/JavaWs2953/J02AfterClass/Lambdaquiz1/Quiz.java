package J02AfterClass.Lambdaquiz1;
interface Quiz1Interface{ int Answer(int x, int y);}
interface Quiz3Interface{ int Answer(int x, int y);};
interface Quiz4Interface{int Answer(int[] ary);};
public class Quiz 
{
    public static void main(String[] args) 
    {
        int n1 = 18;
        int n2 = 21;

        Quiz1Interface q1 = (x,y) -> {return x+y;};
        System.out.println(q1.Answer(n1,n2));

        Quiz3Interface q3 = (x,y) -> (x>y)?x:y;
        System.out.println("Max: " + q3.Answer(n1, n2));

        Quiz4Interface q4 = (ary) ->  {
            int max = ary[0];
            for (int n: ary)
            {
                if(n>max) max=n;
                
            };
            return max;
            
        }; int[] nums = {5,9,1,4};
        System.out.println("Array Max: " +q4.Answer(nums)); 


    }
}
