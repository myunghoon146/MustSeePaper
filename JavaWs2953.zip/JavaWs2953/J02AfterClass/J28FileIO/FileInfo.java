package J02AfterClass.J28FileIO;

import java.io.File;

public class FileInfo 
{
    //파일 정보 출력하는 실습
    public static void main(String[] args) 
    {
        //작업 폴더의 경로 불러오기 > System.getProperty("user.dir")
        String path = System.getProperty("user.dir");
        

        path += "\\J02AfterClass\\J28FileIO\\CuteCat.png";

        System.out.println(path);

        File file = new File(path);

        if(file.exists())
        {
            System.out.println("Name : " +file.getName());
            System.out.println("Path : " +file.getPath());
            System.out.println("Size : " +file.length());
            System.out.println("Parent : " +file.getParent());
            System.out.println("File?: " +file.isFile());
        }
        else
        {
            System.out.println("Can't Find File");
        }

        System.out.println("-------------------");

        path = System.getProperty("user.dir");
        path += "\\J02AfterClass";

        file = new File(path);
        String [] fileList = file.list();

        for(String s: fileList)
        {
            System.out.println(s);
        }

        //디렉토리 내 있는 모든 리스트 긁어오기(File)
        File[] fList = file.listFiles();
        for(File f : fList)
        {
            if(f.isDirectory())
            {
                String[] sList = f.list();

                for(String s : sList)
                {
                    System.out.println(s);
                }
            }
            else if(f.isFile())
            {
                System.out.println("[File]: " +f.getName());
            }
            else
            {
                System.out.println("[Unknown]");
            }


        }



    }    
}
