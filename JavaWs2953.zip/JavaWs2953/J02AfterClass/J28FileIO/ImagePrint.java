package J02AfterClass.J28FileIO;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class ImagePrint 
{
    //사진은 터미널로 출력이 불가능 -> JFrame 이용!!!
    
    public static void main(String[] args) 
    {
        JFrame frame = new JFrame();
        frame.setSize(600,600);
        frame.setBounds(800,0,600,600);
        frame.setResizable(false);
        
        String path = System.getProperty("user.dir");
        path +="\\J02AfterClass\\J28FileIO\\Cutecat.png";

        ImageIcon image = new ImageIcon(path);
        JLabel label = new JLabel();
        frame.add(label);
        frame.setVisible(true);
    }
}
