package J02AfterClass.J28FileIO;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public  class FileReadTest
{
    public static void main(String[] args) 
    {
        String path = System.getProperty("user.dir");
        path +="\\J02AfterClass\\J28FileIO\\testText.txt";

        FileReader fr = null;
        BufferedReader br = null;

        try
        {
            fr = new FileReader(path);
            br = new BufferedReader(fr); 
            
            String line;
            int lineNumber=1;
            while(true)
            {
                line=br.readLine();
                if(line==null) break;
                else System.out.println(lineNumber++ + line);
            }

            br.close();
            fr.close();
        }
        catch(FileNotFoundException e)
        {
            System.out.println("Can't Find File");
        }
        catch(IOException e)
        {
            System.out.println("IO Exception");
        }

        catch(Exception e)
        {

        }

    }   
}
