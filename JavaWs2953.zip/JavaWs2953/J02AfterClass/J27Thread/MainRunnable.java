package J02AfterClass.J27Thread;

class ThreadRun implements Runnable
{

    @Override
    public void run() 
    {
        for(int i=0;i<200;i++)
        {
            System.out.print(i);
        }    
    }
    
}


public class MainRunnable 
{
    public static void main(String[] args) 
    {
        Runnable r = new ThreadRun();

        //ThreadRun이 Runnable을 구현해서 인터페이스로 담기 가능.

        Thread thread = new Thread(r);
        thread.start();

        Runnable r2 = ()->{ 
            for(int i=0;i<200;i++)
        {
            System.out.print(i);
        }    
                            };

       Thread thread2 = new Thread(r2);
       thread2.start();
       
       // 람다방식
       Thread thread4 = new Thread(()->
       {
        for(int i=0;i<200;i++)
        {
            System.out.print(3);
        }
       });
       thread4.start();

       

    }    
}
