package J02AfterClass.J27Thread;

import java.util.Scanner;

class Th2 extends Thread
{
    String food;
    public Th2()
    {
        this.food = "Nothing";
    }
    public Th2(String food)
    {
        this.food = food;
    }

    @Override
    public void run() 
    {
        for(int i=0;i<10;i++)
        {
            System.out.println(food + "is good!");
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }    
    }

}

public class Main2 
{
    public static void main(String[] args) 
    {
        Scanner sc = new Scanner(System.in);
        while(true)
        {   System.out.print("Input Food : ");
            String temp = sc.nextLine();
            if(temp.equals("Quit")) break;

            Th2 thread = new Th2(temp);
            thread.start();
        }

        sc.close();
        
    }    
}
