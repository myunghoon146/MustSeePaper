package J02AfterClass.J27Thread;

import java.awt.BorderLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextField;

class Th3 extends Thread
{
    // 필드
    int number;
    // 생성자
    public Th3(int number)
    {
        this.number=number;
    }
    // 메서드
    @Override
    public void run() 
    {
        for(int i=0;i<10;i++)
        {
            System.out.println(number);
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }

        System.out.println(" Thread End : " + number);
    
    
    }
}

public class Main3 
{
    public static void main(String[] args) 
    {
        JFrame frame = new JFrame("Thread Test");

        frame.setSize(500,500);

        JTextField field = new JTextField();

        JButton button = new JButton("Press");

        frame.add(field,BorderLayout.CENTER);
        frame.add(button,BorderLayout.SOUTH);

        button.addActionListener((e)->{

            field.getText();
            int temp = Integer.parseInt(field.getText());
            Th3 thread = new Th3(temp);
            thread.start();

            field.setText("");
        });

        frame.setVisible(true);
    }    
}
