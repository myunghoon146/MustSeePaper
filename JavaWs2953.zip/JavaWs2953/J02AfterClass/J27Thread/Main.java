package J02AfterClass.J27Thread;

class Th extends Thread
{
    @Override
    public void run() 
    {
        // 1을 200번 출력
        for(int i=0;i<200;i++)
        {System.out.print(1);}   
    }
}


public class Main 
{
    public static void main(String[] args) 
    {
        Th t = new Th();

        long startTime = System.currentTimeMillis();
        t.start();

        try {
            t.join();
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        // 끝나는 시간 측정
        long endTime = System.currentTimeMillis();
        System.out.println("Time : " +endTime/1000);
     // 0 200번 출력
      //  for(int i=0;i<200;i++)
       // {System.out.print(1);
       // try {
       //     Thread.sleep(10);
       // } catch (InterruptedException e) {
            // TODO Auto-generated catch block
        //    e.printStackTrace();
        //}} 



       


    }    
}
