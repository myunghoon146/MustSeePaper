package J02AfterClass.J27Thread;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Toolkit;

import javax.swing.JFrame;
class ThreadFrame extends Thread
{
    //필드
    int frameWidth,frameHeight,xPosition,yPosition;
    Color color;
    String title;
    //생성자
    public ThreadFrame(int frameWidth, int frameHeight, int Xposition, int yPosition,
    Color color, String title)
    {
        this.frameWidth = frameWidth;
        this.frameHeight = frameHeight;
        this.xPosition = xPosition;
        this.yPosition = yPosition;
        this.color = color;
        this.title = title;
    }
    //메서드
    @Override
    public void run() 
    {
        //프레임 만들고
        JFrame frame = new JFrame(title);
        //옵션/ 나 꺼진다고 해서 다른친구들에게 영향 x
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        // 프레임 위치시키고
        frame.setBounds(xPosition, yPosition,frameWidth,frameHeight);
        // 프레임 색 정하고
        frame.getContentPane().setBackground(color);
        // 띄우기
        frame.setVisible(true);
        
        
    }

}

public class MainFrame 
{
    public static void main(String[] args) 
    {
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        
        int width = screenSize.width;
        int height = screenSize.height;

        System.out.println(width+ ','+height);

        // 단위 만들기
        int frameWidth = width/3;
        int frameHeight = height/3;

        // 색 만들기. - Color

        Color[] colors =  new Color[6];
        colors[0] = new Color(221,65,36);
        colors[1] = new Color(240,192,90);
        colors[2] = new Color(136,176,75);

        // 프레임 쓰레드를 6개 만들자!!!!
        for(int i=0;i<2;i++)
        {
            for(int j=0;j<3;j++)
            {
                int x = j * frameWidth;
                int y = i * frameHeight;

                System.out.print("X:   " +x);
                System.out.println(",Y :" +y);

                String title = "Frame - "+(3*i + j+1);
                System.out.println("Title: " +title);

                
            }
        } 
   
        

        
   
    }

}
