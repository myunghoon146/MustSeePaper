package J02AfterClass.J11Method;

import java.util.Random;
import java.util.Scanner;

// 패키지: 폴더명.
// 왜쓰냐?? 클래스 이름이 중복이 안됨. 패키지 다르면 중복됨.
public class Main 
{
    public void Enter()
    {   System.out.println("\n===============================================");
    
    }
    public void LuckyNumber()
    {
        Random rand = new Random();
        System.out.println("Lucky Number : " + rand.nextInt(10));
    }
    // 1. Java에서 원주율을 출력하는 방법이 있습니다.
    // 인터넷에서 찾아서 원주율을 소수점 4자리까지 출력
    // 2. 랜덤한 숫자를 45까지 6개를 뽑아서 출력하ㅡㄴㄴ
    // RandomMachine 메소드 구현하기
        // 여러가지 메소드를 전~~~~~부 넣어보자.
        // 1. 입력도 안받고 리턴도 없고
        
        // 2. 입력 받고 리턴은 없고
        // Overloading 다형성 기술 사용
        public void LuckyNumber(int number)
        {
            Random rand2 = new Random();
            int randomNumber = rand2.nextInt(number);
            System.out.println("Lucky Number: " +randomNumber);
            
        }
        // 3. 입력은 안받고 리턴은 있고
        //1) 랜덤값 100까지 하나 돌려주기
        public int ReturnRandom100()
        {
            Random rand = new Random();
            int result = rand.nextInt(100);
            return result;
           
        }
        //2) PI값 돌려주기
        public double ReturnPI()
        {
            return Math.PI;
        }
        //3) 오늘 뭐 먹을지 돌려주기
        public String RandomFood()
        {
            String[] foods = new String[3];
            foods[0] = "Soon Dae Guk";
            foods[1] = "Stir-fried Pork";
            foods[2] = "Money Gas";

            Random rand7 = new Random();
            int choice = rand7.nextInt();
            return foods[choice];
        }
        
        // 아래의 메소드들을 모두 PrintPlus로 만드세요.
        // 1) 숫자 두개 전달받아서, 두개 더해서 출력
        public void PrintPlus(int n1, int n2)
        {
            
            int result = n1+n2;
            System.out.println("result: " +result);
        }
        // 2) 숫자 세개 전달받아서, 세개 더해서 출력
        public void Printplus2(int n1, int n2, int n3)
        {
            int result2= n1+n2+n3;
            System.out.println("result2: " +result2);
        }
        // 3) 숫자 네개 전달받아서, 네개 더해서 출력
        public void Printplus3(int n1, int n2, int n3, int n4)
        {
            int result3 = n1+n2+n3+n4;
            System.out.println("result3: " +result3);
        }
        // 4) 실수 두개 전달받아서, 두개 더해서 출력
        public void Printplus4(double n1, double n2)
        {
            double result4= n1+n2;
            System.out.println("result4: " +result4);
        }
        // 5) 실수 세개 전달받아서, 세개 더해서 출력
        public void Printplus5(double n1, double n2, double n3)
        {
            double result5 = n1+n2+n3;
            System.out.println("result5: " +result5);
        }
        // 6) 실수 네개 전달받아서, 네개 더해서 출력
        public void Printplus6(double n1, double n2, double n3, double n4)
        {
            double result6 = n1+n2+n3+n4;
            System.out.println("result6: " +result6);
        }
        // 4. 입력, 리턴 모두 있음.
        // 1.1) 넘겨받은 숫자까지 랜덤값 만들어서 돌려주기 ReturnIntRandom
        public int ReturnIntRandom(int n1)
        {
            Random rand = new Random();
            int randomValue = rand.nextInt(n1);
            return randomValue;
          
            

            
        }

        // 1.2) 넘겨받은 실수까지 랜덤값 만들어서 돌려주기 ReturnDoubleRandom
        public double ReturnDoubleRandom(double n1)
        {
            Random rand5 = new Random();
            return rand5.nextDouble();

        }
        // 2) 넘겨받은 문자의 길이를 계산해서 돌려주기 ReturnStringLength
        public int ReturnStringLength(String s)
        {
            int len = s.length();
            return len;
        }
        // 3) 넘겨받은 숫자만큼 배열 만든후, 두번째로 넘겨받은 숫자범위까지 랜덤하게 배열에 값을 채워서 리턴
        public int[] ReturnArray(int size, int randomSize)
        {
            int[] array = new int[size];
            Random rand = new Random();
            for(int i=0;i<size;i++)
            {
                array[i]=rand.nextInt(randomSize);
            }
            return array;
        }
        public static void main(String[] args)
        {
            // 메소드 사용 방법
            // 1. 객체를 만든다(클래스 이름 사용)
            Main dongas = new Main();
            // 2. 만든 객체에 .을 붙여서 일시키기
            dongas.Enter();
            dongas.LuckyNumber();
            dongas.LuckyNumber(90000);
            dongas.PrintPlus(23,57);
            dongas.Printplus2(37, 25, 13);
            dongas.Printplus3(89,25,17,3);
            dongas.Printplus4(23.75,37.50);
            dongas.Printplus5(37.50,23.13,10.76);
            dongas.Printplus6(13.75,37.50,27.73,10.75);
            int randomValue = dongas.ReturnRandom100();
            System.out.println("Random Value:" +randomValue);
            
            double piValue = dongas.ReturnPI();
            System.out.printf("Pi(.4): %.4f\n",piValue);

            
            int[] array = dongas.ReturnArray(5,10);
            for(int i=0;i<array.length;i++)
            {
                System.out.print(array[i]+"");
            }
            
            int max =12;
            int randomValue2 = dongas.ReturnIntRandom(37);
            System.out.println("1부터 사이의 랜덤값: " +randomValue2);



        }
    
}
