package J02AfterClass.J17TotalClass.Quiz3;

public class Main

{
    public static void main(String[] args)
    {
        Person[] FriendsList = new Person[3];
        FriendsList[0]= new Person("Marry", "INFP",3);
        FriendsList[1]= new Person("Ever", "ISTJ",5);
        FriendsList[2]= new Person("Korae", "ENFJ",8);
        
    
        int maxPower=FriendsList[0].power;
        int maxIndex=0;
        int minPower=FriendsList[0].power;
        int minindex=0;

        for(int i=0;i<FriendsList.length;i++)
        {
            FriendsList[i].Introduce();
            if(FriendsList[i].power>maxPower)
            {
                maxPower = FriendsList[i].power;
                maxIndex = 0;
            }

            if(FriendsList[i].power<minPower)
            {
                minPower = FriendsList[i].power;
                minindex=i;
            }

        }
        System.out.println("Strong :" +FriendsList[maxIndex].name);
        System.out.println("Weak :" +FriendsList[minindex].name);


    
    
    
    
    
    }


}
