package J02AfterClass.J17TotalClass.Quiz3;


public class Person 
{
    String name;
    String mbti;
    int power;
    
    protected Person(String name, String mbti, int power)
    {
        this.name=name;
        this.mbti=mbti;
        this.power=power;
    }

    public void Introduce()
    {
        System.out.println("Name" + name);
        System.out.println("MBTI" +mbti);
    }

    // Getter Setter -> 값을 가져오거나 수정을 내가 만든 로직 따라 실행 "제어"
    public String GetName()
    {
        return this.name;
    }

    public void SetName(String name)
    {
        System.out.println("Don't Touch Name");
    }
    public void SetPower(int power)
    {
        if(power<0 || power>20)
        {
            System.out.println("Power is 0~20");
        }
        else this.power=power;
    }
}
