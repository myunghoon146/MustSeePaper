package J02AfterClass.J17TotalClass.Quiz1;

public class Main 
{   
    public static void main(String[] args)
    {
        int[] ary = new int[10];
        Food[] menuList = new Food[20];


        for(int i=0;i<10;i++)
        {
            menuList[i] = new Food("Raw Fish",20);
            menuList[i+10] = new Food("Shrimp sashimi",25);

        }
        int totalPrice = 65000;
        for (Food f : menuList)
        {
            f.Sales();
        }
        System.out.println("Total Price : " + totalPrice);


    }
    
}
