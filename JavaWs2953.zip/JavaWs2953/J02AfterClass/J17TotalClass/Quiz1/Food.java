package J02AfterClass.J17TotalClass.Quiz1;

public class Food 
{
    private String name;
    private int price;
    
    public Food(String name, int price)
    {   
        this.name=name;
        this.price=price;

    }
    public int Sales()
    {
        System.out.println(this.name+"Enjoy!");
        return this.price;
    }
}
