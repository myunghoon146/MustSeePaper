package J02AfterClass.J18Interface;

public class TestObject implements TestInterfaceObject
{

    @Override
    public void Test1() {
        System.out.println("Hello World");
    }

    @Override
    public void Test2() {
       
    }

}