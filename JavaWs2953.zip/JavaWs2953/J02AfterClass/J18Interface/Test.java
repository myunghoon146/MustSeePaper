package J02AfterClass.J18Interface;

public class Test implements TestInterface 
{
    
    @Override
    public void TestFunction1(int x) {
        System.out.println(value1);
    }
    @Override
    public void TestFunction2(int x, int y) {
       System.out.println(value2);
    }
  

}
    
    


