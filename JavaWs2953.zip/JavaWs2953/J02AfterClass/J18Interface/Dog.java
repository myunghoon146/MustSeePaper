package J02AfterClass.J18Interface;

public class Dog implements Animal
{

    @Override
    public void Bark() {
        System.out.println("Wa Wa");
    }

    @Override
    public void Walk() {
        System.out.println("Fast Fast");
    }

    @Override
    public void Sleep() {
        System.out.println("Kul Kul");
    }

    @Override
    public void Eat() {
        System.out.println("Uguk Uguk");
    }

    @Override
    public void Run() {
        System.out.println("Wow Wow");
    }
}
