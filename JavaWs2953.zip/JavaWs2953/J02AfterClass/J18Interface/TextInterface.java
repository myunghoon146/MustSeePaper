package J02AfterClass.J18Interface;

public interface TextInterface 
{
    public static final String[] LINES=
    { "1. Ora Ora Ora Ora Ora Ora!",
    "2. do you remember how many breads you have eaten in your life?",
    "3. Gold Experience Requiem!",
    "4. Your next line is ... 'What?!",
    "5. Muda Muda Muda Muda Muda"
    };

    public abstract void PCurrent();
    public abstract void PNext();
    public abstract void PPreview();
    public abstract void Reset();
    public abstract void PAll();
}
