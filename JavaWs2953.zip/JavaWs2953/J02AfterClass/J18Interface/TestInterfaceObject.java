package J02AfterClass.J18Interface;

public interface TestInterfaceObject 
{
    public abstract void Test1();
    public abstract void Test2();
    
}
