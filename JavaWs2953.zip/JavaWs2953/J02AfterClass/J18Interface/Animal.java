package J02AfterClass.J18Interface;
public interface Animal 
{
    public static final int maxLife =20;

    public abstract void Bark();
    public abstract void Walk();
    public abstract void Sleep();
    public abstract void Eat();
    public abstract void Run();
}