package J02AfterClass.J18Interface;

public interface TestInterface 
{
    //필드 (public static final 자동)
    public static final int value1 = 10;
    public static final String value2 = "Hello";
   // final 필드는 초기화로 처음부터 값 넣어야 함.
    //메소드 (public abstract)
    
    public abstract void TestFunction1(int x);
    public abstract void TestFunction2(int x, int y);

    // 생성자 X

}
