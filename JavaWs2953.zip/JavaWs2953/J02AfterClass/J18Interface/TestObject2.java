package J02AfterClass.J18Interface;

public class TestObject2 implements TestInterfaceObject
{

    @Override
    public void Test1() {
        System.out.println("Hello Everybody");
    }

    @Override
    public void Test2() {
        System.out.println("OH MY GOSH");
    }

    public void Test3()
    {
        System.out.println("Oh No");
    }
    
}
