package J02AfterClass.J18Interface;

public class Squirrel implements Animal 
{

    @Override
    public void Bark() {
        System.out.println("Kkik Kkik");
    }

    @Override
    public void Walk() {
       System.out.println("Too slender");
    }

    @Override
    public void Sleep() {
        System.out.println("No Sound");
    }

    @Override
    public void Eat() {
        System.out.println("No Sound");
    }

    @Override
    public void Run() {
        System.out.println("At Speed");
    }
    
}
