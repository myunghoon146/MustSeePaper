package J02AfterClass.J18Interface;

public class TextPrinter implements TextInterface 
{
    int currentPage;

    public TextPrinter()
    {
        currentPage=0;
    }
    @Override
    public void PCurrent() 
    {
        System.out.println(LINES[currentPage]);
    }

    @Override
    public void PNext() {
       currentPage++;
       currentPage = currentPage % LINES.length;
       
    }

    @Override
    public void PPreview() {

        System.out.println( "2. do you remember how many breads you have eaten in your life?");
       
    }

    @Override
    public void Reset() {
        
        System.out.println("1. Ora Ora Ora Ora Ora Ora!");
       
    }

    @Override
    public void PAll() 
    {
        
    }
    
}
