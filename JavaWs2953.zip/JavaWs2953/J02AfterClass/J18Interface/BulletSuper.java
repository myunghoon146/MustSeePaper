package J02AfterClass.J18Interface;

public class BulletSuper 
{
    int bulletSpeed;

    public BulletSuper(int bulletSpeed)
    {
        this.bulletSpeed= bulletSpeed;

    }

    protected void Test()
    {
        System.out.println("My Private Method");
    }
}
