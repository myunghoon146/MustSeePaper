package J02AfterClass.Quiz2;

public interface Bullet 
{
    public abstract void Fire();
}
