package J02AfterClass.Quiz2;

public class BreachSlug implements Bullet
{
    int bulletSpeed;
    public BreachSlug(int bulletSpeed)
    {   super();
        bulletSpeed=20;
    }


    @Override
    public void Fire() {
       System.out.println("Pak!!!!" + bulletSpeed);
      
    }

    
}
