package J02AfterClass.Quiz2;

public class APSlug 
{
    
}
