package J02AfterClass.Quiz2;

import java.util.Stack;

public class Shotgun 
{
    // 필드
    Stack<Bullet> magazine;
    int maxCapacity;
    // 생성자
    public Shotgun(int maxCapacity)
    {
        this.maxCapacity = maxCapacity;
        this.magazine = new Stack<>();
    }
    // 메서드   
    void Reload()
    {
        if(magazine.size()<maxCapacity)
        {
            magazine.push(new BreachSlug(maxCapacity));
           
        }
    }

    void Reload(boolean allReload)
    {
        if(magazine.size()<maxCapacity && allReload==true)
        {
            int reloadNum = maxCapacity - magazine.size();
            for(int i=0;i<reloadNum;i++)
            {
                Reload();
            }
        }
        else
        {
            System.out.println("Full");
        }

        
    }
    void Fire()
    {
        if(magazine.empty()==false)
        {
            magazine.pop().Fire();
        }
        else
        {
            System.out.println("Empty");
        }
    }
}
