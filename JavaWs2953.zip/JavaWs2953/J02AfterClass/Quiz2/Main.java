package J02AfterClass.Quiz2;

public class Main 
{
    public static void main(String[] args)
    {
        Shotgun m91 = new Shotgun(2);
        m91.Reload();
        m91.Reload(false);
        m91.Fire();
        m91.Fire();
        System.out.println("---------");
        m91.Reload();
        m91.Fire();
        m91.Fire();
    }   
}
