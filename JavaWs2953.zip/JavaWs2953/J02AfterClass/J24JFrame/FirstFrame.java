package J02AfterClass.J24JFrame;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Image;
import java.awt.LayoutManager;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class FirstFrame 
{
    public static void main(String[] args)
    {
        JFrame frame = new JFrame("Title");
        frame.setSize(500,500);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocation(50, 50);

        //------------------------------
        //요소 추가하기.
       JLabel label = new JLabel("Hello label");
       JButton button = new JButton("Hello Button");
       JTextField field = new JTextField(1);
        
       // frame.add(label);
       // frame.add(button);
       // frame.add(field);
       JButton[] buttons = new JButton[10];
       int buttonNumber=1;
       for(int i=0;i<10;i++)
       {
            buttons[i] = new JButton("Button" + buttonNumber++);
       } 


       // Border Layout
       // 레이아웃 설정
    //   frame.setLayout(new BorderLayout());

       // 요소 배치하기
    //   frame.add(buttons[0],BorderLayout.NORTH);
    
    
    // Flow Layout
    // 레이아웃 설정
    frame.setLayout(new FlowLayout(0,20,20));

    //요소 배치
    for(JButton but: buttons)
    {
        frame.add(but);
    }

        // 화면에 출력하기
        frame.setVisible(true);
    }    
}
