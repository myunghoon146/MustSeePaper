package J02AfterClass.J15Inheritance;

public class Sub2 extends Super2 
{
    int value3;

    public Sub2()
    {
        this(30);
        System.out.println("Sub 2 Construction");

    }
    public Sub2(int temp)
    {
        this.value3 = temp;
        System.out.println("Sub2's Other Cons");
    }
}
