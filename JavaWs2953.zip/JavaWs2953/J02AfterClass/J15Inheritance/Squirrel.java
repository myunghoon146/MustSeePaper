package J02AfterClass.J15Inheritance;

public class Squirrel extends Animal
{
    int magic;

    public Squirrel(String name,int age,int magic)
    {
        super(name, age);
        this.name=name;
        this.age=age;
        this.magic=magic;

    }

    public void WaterBolt()
    {
        System.out.println("Magic" +magic);
    }
    
}
