package J02AfterClass.J15Inheritance;

public class Cat extends Animal
{
        int stealth;    

        public Cat(String name, int age, int stealth)
        {
            super(name, age);
            this.name=name;
            this.age=age;
            this.stealth=stealth;

        }

        public void StealthAttack()
        {
            System.out.println("Stealth" +stealth);
        }
}
