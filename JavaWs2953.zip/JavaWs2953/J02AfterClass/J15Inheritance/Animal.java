package J02AfterClass.J15Inheritance;

public class Animal 
{
    protected String name;
    protected int age; 
    // 상속해주고 싶은 것은 protected로 처리할 것.
    // 상속해주기 싫다면 private로 처리하기
    
    
    public Animal(String name, int age)
    {
        this.name= name;
        this.age = age;
    }
    protected void Sleep()
    {
        System.out.println("Zzzz.........");
    }
    protected void Eat()
    {
        System.out.println("nymnymnymsakdfn");
    }

}
