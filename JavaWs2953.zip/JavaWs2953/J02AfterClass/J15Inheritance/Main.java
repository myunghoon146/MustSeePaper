package J02AfterClass.J15Inheritance;

public class Main 
{
    public static void main(String[] args)
    {
        //Sub2 sb =new Sub2();

        Dog wall = new Dog("Wall-E",4,10);
        wall.Eat();
        wall.Sleep();
        wall.PowerStrike();

        Cat luna = new Cat("lunaya",7,21);
        luna.Eat();
        luna.Sleep();
        luna.StealthAttack();

        Squirrel peter = new Squirrel("peterya",5,12);
        peter.Eat();
        peter.Sleep();
        peter.WaterBolt();

        




    }


    
}
