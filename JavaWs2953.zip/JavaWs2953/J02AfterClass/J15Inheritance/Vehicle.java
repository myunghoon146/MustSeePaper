package J02AfterClass.J15Inheritance;

public class Vehicle 
{
    String model;
    int capacity;
    int price;

    public Vehicle(String model,int capacity, int price)
    {
        this.model=model;
        this.capacity=capacity;
        this.price=price;
    }

    public void Move()
    {
        System.out.print("Strat Move");
    }
    
}
