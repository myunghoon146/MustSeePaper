package J02AfterClass.J15Inheritance;

public class Dog extends Animal
{
    private int strength;

    public Dog(String name, int age, int strength)
    {
        super(name, age);
        this.name=name;
        this.age = age;
        this.strength= strength;
    }

    public void PowerStrike()
    {
        System.out.println("Power" + strength);
    }
    
}
