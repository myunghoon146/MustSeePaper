package J02AfterClass.J15Inheritance;

public class Super2 
{
    int value1;
    int value2;
    public Super2()
    {
        this(10,20);
        System.out.println("Super2 Construction");

    }   

    public Super2(int x, int y)
    {
        
        this.value1= x;
        this.value2= y;
        System.out.println("Super2 x Other Cons");
    }
}
