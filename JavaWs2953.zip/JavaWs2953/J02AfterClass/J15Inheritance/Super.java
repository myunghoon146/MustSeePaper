package J02AfterClass.J15Inheritance;

public class Super {
    public int value1;
    private int value2;
    protected int value3;
    int value4;
    
    public Super()
    {
        this.value1 = 18;
    }
    public void Test1()
    {

    }
    protected void Test2()
    {

    }
    private void Test3()
    {

    }
    void Test4()
    {
        
    }
}
