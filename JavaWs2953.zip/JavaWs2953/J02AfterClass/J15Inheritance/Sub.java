package J02AfterClass.J15Inheritance;

public class Sub extends Super 
{

    int value5;


    public Sub()
    {
        this.value1 = 10;
       // this.value2 = 20; //private
        this.value3 = 30;
        this.value4 = 50;
        this.value5 = 60;

        this.Test1();
        this.Test2();
        
        this.Test4();
        this.Test5();

        super.Test1();
        super.Test2();
        super.Test4();
        
    }
    void Test5()
    {

    }
    
}
