package J02AfterClass.J22API;

class A
{

}
class B
{

}
class C extends B
{

}
public class Main 
{
    public static void main(String[] args) 
    {
        A a1 = new A();
        A a2 = new A();
        A a3 = a2;

        System.out.println(a1.equals(a2));
        System.out.println(a1.equals(a3));
        System.out.println(a2.equals(a3));

        System.out.println(a1.hashCode());
        System.out.println(a2.hashCode());

        //getClass -> 클래스 객체의 정보를 출력
        System.out.println(a1.getClass());


        System.out.println(a1.toString());
        System.out.println(a2.toString());


        // ============================
        // String Test

        String s1 = "Hello World";
        String s2 = "Hello World";
        String s3 = new String("Hello World");
        String s4 = s3;

        System.out.println(s1.hashCode());
        System.out.println(s2.hashCode());
        System.out.println(s3.hashCode());
        System.out.println(s4.hashCode());

        System.out.println(s1 == s2);
        System.out.println(s1 == s3);
        System.out.println(s1 == s4);
        System.out.println(s2 == s3);
        System.out.println(s2 == s4);
        System.out.println(s3 == s4);

        System.out.println(s1.equals(s2));
        System.out.println(s2.equals(s3));

        System.out.println(s1.toString());

        System.out.println(s1.getClass());

        // 해시란?
        // studentID = 100 --> 123456789
        // x/100*123456789
        // studentID = 243 -> 299999997

        // =============================== Test Class 실습
        TestClass tc1 =new TestClass(10, 20);
        TestClass tc2 = new TestClass(10, 20);

        //toString
        System.out.println(tc1);
        System.out.println(tc1.toString());
        System.out.println(tc2);
        System.out.println(tc2.toString());
        //equals
        System.out.println(tc1.equals(tc2));
        System.out.println(tc1 == tc2);
        //hashCode
        System.out.println(tc1.hashCode());
        System.out.println(tc2.hashCode());
        //getClass
        System.out.println(tc1.getClass());
        System.out.println(tc2.getClass());

        System.out.println("======================");
        System.out.println("Student Class");
        Student stu1 = new Student('A');
        Student stu2 = new Student('A');

        System.out.println(stu1);

        System.out.println(stu1.equals(stu1));

        System.out.println(stu1.hashCode());
        System.out.println(stu2.hashCode());


        
    }            
}
