package J02AfterClass.J22API;

public class TestClass 
{
    int value1;
    int value2;
    
    public TestClass(int value1, int value2)
    {
        this.value1 = value1;
        this.value2 = value2;
    }
    // toString Override
    @Override
    public String toString() {
       System.out.println("Value1 : " +value1+ ", Value2 : " +value2);
       return null;
       
    }
    // equals   Override
    @Override
    public boolean equals(Object obj) 
    {
      //Object obj 자리는 모~~~든 객체가 들어올 수 있음.
      // 일단 obj가 TestClass인지 확인 먼저 필요! >instanceof
      // 사용방법 : 객체 instanceof 클래스이름

      if (obj instanceof TestClass)
      {
        TestClass temp = (TestClass)obj;
        if(temp.value1 == this.value1 && temp.value2==this.value2)
        {
            return true;
        }     
     }
      else
      {
        return false;
      }
      return false;
    }
    // hashCode Override
    // equals를 오버라이드 했으면 hashCode도 같이 수정해야함(권장)
    // 지금은 문제없지만 hashSet, hashTree와 같이 hash 자료형을 
    // 사용하게 되는 경우, 문제가 발생한다. 
    // 사용법
    // java.util.Objects.hash(이안에 때려넣기)
    @Override
    public int hashCode() {
       return java.util.Objects.hash(this.value1,this.value2);
    }
}
