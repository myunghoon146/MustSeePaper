package J02AfterClass.J22API;

public class Student 
{
    String name;
    int studentID;
    static int idCnt=1000;

    public Student(String name)
    {
        this.name=name;
        this.studentID=idCnt++;
    }

    public Student(char c) {
        //TODO Auto-generated constructor stub
    }

    @Override
    public String toString() {
      return "Name: " +this.name + ",ID: "+this.studentID;
    }
    @Override
    public boolean equals(Object obj) {
       // studentID가 같으면 같은 학생!!
       // obj가 Student 클래스인지 확인
       if (obj instanceof Student)
       {
        if(this.studentID == ((Student)obj).studentID)
        {
            return true;
        }
       }
       else 
       {
        return false;
       }
       return false;
    }

    @Override
    public int hashCode() {
        return java.util.Objects.hash(this.studentID);
    }
}
