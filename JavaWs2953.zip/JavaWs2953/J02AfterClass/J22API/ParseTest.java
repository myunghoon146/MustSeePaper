package J02AfterClass.J22API;
import java.util.Scanner;
public class ParseTest 
{
    public static void main(String[] args) 
    {
       Scanner sc = new Scanner(System.in);
       System.out.print("Input Number : ");
       String val = sc.nextLine();
       //입력한 숫자에 10 곱해서 출력하고싶음.
       try{int temp = Integer.parseInt(val);} 
       finally
       {
        System.out.println("End");
       }
       
    }    
}
