package J02AfterClass.J13ClassTest;

import J02AfterClass.U;

public class Main 
{

    public static void main(String[] args)
    {
       
        
        //결론 
        //필드에 값을 넣지 않은 상태로 사용시 에러가 발생.
        // 객체 만들었으면 꼭 값들을 넣어주자.
        // 1. 직접 값을 대입(t3 참고)
        // 2. 메소드 만들어서 값을 대입(t, t2 참고)
        // 3. ?????? (아직 안배움)
   
        
       Pizza peperoni = new Pizza();
       peperoni.pizzaName="Peperoni Pizza";
       peperoni.price= 25000;
       peperoni.Introduce();

       Pizza mine = new Pizza();
       mine.pizzaName = "Hawaiian Pizza";
       mine.price=22900;
       mine.Introduce();
   
        Chicken gcova = new Chicken();
        gcova.chickenName="G Co Va Chicken";
        gcova.time=3;
        gcova.price=23500;
        
        gcova.Introduce();
        gcova.JiggleJiggle();
   


        

        U.P("My Name: " +U.myName);
        U.PrintCallCount();
        

    }
    
}
