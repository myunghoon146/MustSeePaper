package J02AfterClass.J13ClassTest;

public class Test {
    // main 기본셋팅 x

    //필드
    int value1=10;
    String name;
    double value2;
    int[] array;
    //생성자(안배움)


    //메소드
    public void SettingField(int value1, String name, double value2, int arySize)
    {
       //this는 객체 자기 자신이 가지고 있는 필드/메소드
        this.value1= value1;
        this.name = name;
        this.value2=value2;
        array= new int[arySize];

    }
    
    

}
