package J02AfterClass.J13ClassTest;

import J02AfterClass.U;

public class Pizza {

    String pizzaName;
    int price;

    public void Introduce()
    {

       

        U.P(pizzaName);
        U.P(price);
        U.Enter();

    }

  
}
