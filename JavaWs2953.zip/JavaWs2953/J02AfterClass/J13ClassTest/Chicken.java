package J02AfterClass.J13ClassTest;

import J02AfterClass.U;

public class Chicken 
{
    // 변수
    int time;
    String chickenName;
    int price;
    //생성자
    //메소드
    public void Introduce()
    {
        U.P(time);
        U.P(chickenName);
        U.P(price);
        U.Enter();
    }

    public void JiggleJiggle()
    {
        for(int i=0;i<time;i++)
        {
            U.P("지");
            try {
                Thread.sleep(5);
            } catch (InterruptedException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            U.P("글");
            U.P("지");
            U.P("글");
        }
       
        }
    }

    

