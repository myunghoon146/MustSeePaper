package J02AfterClass.J23Generic;

public class BoxBefore 
{
    Object[] o;
    int index;
    private int maxIndex;
    
    public BoxBefore(int size)
    {
        o = new Object[size];
        index=0;
        this.maxIndex=size;
    }

    void SetBox(Object o)
    {   
        if(index>maxIndex)
        {
            System.out.println("Box Full");
        }
        else
        {
            this.o[index] = o;
            index++;
        }
        this.o[index] = o;
        index++;
    }
    Object GetBox()
    {   if(index>=1)
        {
        
        index--;
        Object o = this.o[index];
        return o;
        }
        else
        {
            System.out.println("Box Empty");
            return null;
        }
    }
    int ReturnSize()
    {
    return index;
    } 
}
// 객체 빼주는 메서드
// 사이즈 알려주는 함수
