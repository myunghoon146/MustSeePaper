package J02AfterClass.J23Generic;

public class Jelly extends Food
{
    
    int chewing;
    public Jelly(String name, int chewing)
    {
        super(name);
        this.name=name;
        this.chewing=chewing;
    }   
    @Override
    public void Introduce()
    {
        System.out.println("Jelly" + name + ", " +chewing);
    }
    public void Chewing()
    {
        System.out.println("Chew Chew...");
    }

}
