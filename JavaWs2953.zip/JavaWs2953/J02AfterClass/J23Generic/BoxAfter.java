package J02AfterClass.J23Generic;

public class BoxAfter<T> 
{
    Object[] o;
    int index;
    private int maxIndex;
    
    public BoxAfter(int size)
    {
        o = new Object[size];
        index=0;
        this.maxIndex=size;
    }

    void SetBox(T o)
    {   
        if(index>maxIndex)
        {
            System.out.println("Box Full");
        }
        else
        {
            this.o[index] = o;
            index++;
        }
        this.o[index] = o;
        index++;
    }
    @SuppressWarnings("unchecked")
    T GetBox()
    {   if(index>=1)
        {
        
        index--;
        T o = (T)this.o[index];
        return o;
        }
        else
        {
            System.out.println("Box Empty");
            return null;
        }
    }
    int ReturnSize()
    {
    return index;
    } 
}
