package J02AfterClass.J23Generic;

public class Main 
{
    public static void main(String[] args) 
    {
        BoxBefore box = new BoxBefore(10);


        box.SetBox("Hello World");
        box.SetBox((Integer)12345);
        box.SetBox(new Chip("Swing"));
        box.SetBox(new Jelly("MyGummy",5));
        int boxSize = box.ReturnSize();
        for(int i=0;i<boxSize;i++)
        {
            Object temp = box.GetBox();
        if(temp instanceof Chip)
        {
            Chip c = (Chip)temp;
            c.Introduce();
            c.Sound();
        }
        else if(temp instanceof Jelly)
        {
            Jelly j = (Jelly)temp;
            j.Introduce();
            j.Chewing();
        }
        else
        {
            System.out.println("Unknown");
            temp.toString();
        }
        }
        box.GetBox();
        Object temp = box.GetBox();
        if(temp instanceof Chip)
        {
            Chip c = (Chip)temp;
            c.Introduce();
            c.Sound();
        }
        else if(temp instanceof Jelly)
        {
            Jelly j = (Jelly)temp;
            j.Introduce();
            j.Chewing();
        }
        else
        {
            System.out.println("Unknown");
            System.out.println(temp.toString());
        }
        System.out.println("-----------------------");

        // 제너릭을 쓰는 버전 >BoxAfter.java
        BoxAfter<Chip> boxChip = new BoxAfter<>(10);
        BoxAfter<Jelly> boxJelly = new BoxAfter<>(10);

        boxChip.SetBox(new Chip("Poka"));
        boxChip.SetBox(new Chip("Potato"));
        boxJelly.SetBox(new Jelly("Haribo",5));

        boxChip.GetBox().Introduce();
        boxJelly.GetBox().Introduce();

       

        // Chip, Jelly -> Food클래스 상속 -> Introduce

        BoxAfter<Food> boxFood = new BoxAfter<>(10);
        boxFood.SetBox(new Chip("Swing"));
        boxFood.SetBox(new Jelly("Haribo",5));

        boxFood.GetBox().Introduce();
        boxFood.GetBox().Introduce();



    }    
}
