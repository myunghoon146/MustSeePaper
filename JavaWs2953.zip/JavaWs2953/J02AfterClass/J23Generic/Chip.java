package J02AfterClass.J23Generic;

public class Chip extends Food
{   
    public Chip(String name)
    {
        super(name);
    }
    
    public void Sound()
    {
        System.out.println("Crunch..!");
    }

}
