package J02AfterClass.J23Generic;

public class Food 
{
    String name;
    
    public Food(String name)
    {
        this.name=name;
        
    }   
    public void Introduce()
    {
        System.out.println("Jelly" + name);
    }

}
