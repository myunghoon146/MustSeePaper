package J02AfterClass.J21TryCat;
import java.util.Scanner;
public class Account 
{
    String password;
    static int failCount=0;

    public Account(String password)
    {
        SetPassword(password);
    }

    public void SetPassword(String password)
    {
        this.password=password;
    }
    public void PasswordCheck(String password) throws Exception 
    {
       if(failCount>=3)
       {
        throw new Exception("Account Lock");
       }
       
        if(this.password == password)
        {
            System.out.println("Success");
            failCount=0;
        }
        else
        {
            failCount++;
            if(failCount>=3)
            {
                throw new Exception("Account Lock");
            }
        }
    }
}
