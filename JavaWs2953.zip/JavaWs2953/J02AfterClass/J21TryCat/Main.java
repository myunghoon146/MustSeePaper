package J02AfterClass.J21TryCat;

import java.util.InputMismatchException;

public class Main 
{
    public static void main(String[] args) 
    {
        try {
            Tazza.Test();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            System.out.println(e.getMessage());
        }    

        try {Tazza.Test2();}
        catch(InputMismatchException e)
        {
            System.out.println(e.getMessage());
        } 


    }
}
