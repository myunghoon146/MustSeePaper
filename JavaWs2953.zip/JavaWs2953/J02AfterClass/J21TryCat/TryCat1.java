package J02AfterClass.J21TryCat;
import java.util.InputMismatchException;
import java.util.NoSuchElementException;
import java.util.Scanner;
public class TryCat1 
{
    public static void main(String[] args) 
    {
        String[] colors = {"red","blue","green"};
        Scanner sc = new Scanner(System.in);
        System.out.println("Input 0~2 :");
        try
        { int input = sc.nextInt();
             System.out.println("Your Color :" +colors[input]);

        }
        catch(InputMismatchException asdf)
        {
            System.out.println("Please check your value.");
        }
        catch(ArrayIndexOutOfBoundsException e)
        {
            System.out.println("Please Check Your Index.");
            System.out.println("Error Message : " + e.getMessage());
        }
        catch(NoSuchElementException e)
        {
            System.out.println("\nByeBye~1");
        }
        catch(Exception e)
        {
            System.out.println("Call Mangae Please(010-2584-8343)");
        }
        finally
        {
        sc.close();
        }
    }
}
