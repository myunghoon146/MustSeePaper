package J02AfterClass.J21TryCat;

public class Bank
{
    int balance;
    String ownerName;
    
    public Bank(int balance,String ownerName)
    {
        this.balance=balance;
        this.ownerName=ownerName;
    }

    public void Deposit(int amount) throws Exception
    {
        if (amount>=0)
        {
            this.balance+=amount;
            System.out.println("Deposit Complete");
        }
        else
        {
            throw new Exception ("Please check your deposit amount");
        }

    }
    public void Withdraw(int amount) throws Exception
    {
        if (amount>=0)
        {
            throw new Exception("Teong Teong");
        }
        else
        {
            balance-=amount;
            System.out.println("Withdraw Complete");
        }
    }

    public void ShowBalance()
    {
        System.out.println("Balance: " +this.balance);
    }

    int GetBalance()
    {
        return this.balance;
    }
}
