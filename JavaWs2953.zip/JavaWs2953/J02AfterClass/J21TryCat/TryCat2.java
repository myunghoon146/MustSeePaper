package J02AfterClass.J21TryCat;
import java.util.Scanner;
public class TryCat2 
{
    public static void main(String[] args) 
    {
        int stuscore;
        
            for (int i=0;i<=100;i++)
        {
            Scanner sc = new Scanner(System.in);
            stuscore=sc.nextInt();
            System.out.println("Student Score: " +stuscore);
        }  
       
    }    
}
