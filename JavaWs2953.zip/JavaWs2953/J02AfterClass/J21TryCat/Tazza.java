package J02AfterClass.J21TryCat;

import java.util.InputMismatchException;

public class Tazza 
{
    public static void Test() throws Exception
    {
        System.out.println("Error Throw!");
        throw new Exception("New Exception!");
    }    
    public static void Test2() throws InputMismatchException
    {
        System.out.println("Input Exception Throw!");
        throw new InputMismatchException("Input Mismatch");
    }
}
