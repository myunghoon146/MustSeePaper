package J02AfterClass.J16Override;
public class Chicken
{
    String name;
    int kcal;
    int price;

    public Chicken(String name,int kcal, int price)
    {
        this.name=name;
        this.kcal=kcal;
        this.price=price;
    }

    public void EatSound()
    {
        System.out.println("Crunch Crunch");
    }


}