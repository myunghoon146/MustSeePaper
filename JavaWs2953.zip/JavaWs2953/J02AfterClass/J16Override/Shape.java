package J02AfterClass.J16Override;

public class Shape
{
    protected void Introduce()
    {
        System.out.println("Do Brother");
    }    
}
