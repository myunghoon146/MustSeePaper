package J02AfterClass.J16Override;

public class Circle extends Shape 
{   @Override
    protected void Introduce()
    {
        System.out.println("Circle");
        System.out.println("-------------");
        super.Introduce();
    }

    protected void Introduce(String message)
    {
        System.out.println(message);
    }
}
