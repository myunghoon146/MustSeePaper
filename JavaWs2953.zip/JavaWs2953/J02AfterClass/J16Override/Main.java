package J02AfterClass.J16Override;

public class Main 
{
    public static void main(String[] args)
    {
        Shape s = new Shape();
        s.Introduce();

        Circle c = new Circle();
        c.Introduce();
        c.Introduce("Hello");

    }
    
}
