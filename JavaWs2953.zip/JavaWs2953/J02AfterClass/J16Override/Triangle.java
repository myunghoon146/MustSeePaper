package J02AfterClass.J16Override;

public class Triangle {
    
}
