package J02AfterClass.J00DataStructor.Quiz2;

public interface Menu 
{
    
   
   public abstract void Making();
   public abstract void Introduce();
   public abstract int GetPrice();
   public abstract String GetName();
    



}
