package J02AfterClass.J00DataStructor.Quiz2;

import java.util.ArrayList;
import java.util.List;

public class Order 
{
    List<Menu> orderList;
    public Order()
    {
        this.orderList = new ArrayList<>();
    }

    public void AddList(Menu menu)
    {
        orderList.add(menu);
        String s = menu.GetName() + "Complete Add, Current :" + orderList.size() +"Ea";
        System.out.println(s);
    }

    public void TotalPrice()
    {
        int totalPrice = 0;
        for (Menu m : orderList)
        {
            totalPrice += m.GetPrice();
        }
        orderList.clear();
        System.out.println("Total Price : " + totalPrice + "Won");
    }

    public void ShowAll()
    {
        for(Menu m : orderList)
        {
            m.Introduce();
        }
    }
}
