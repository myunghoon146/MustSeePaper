package J02AfterClass.J00DataStructor.Quiz2;

public class Burger implements Menu 
{
    String name;
    int price;
    
    public Burger(String name,int price)
    {
        this.name=name;
        this.price=price;
    }
    
    @Override
    public void Making() {
        
        System.out.println("Chik Chik");
    }
    @Override
    public void Introduce() 
    {
        System.out.println("Name : " + this.name + "Price: " + this.price);   
    }
    @Override
    public int GetPrice() 
    {
       return price;
    }

    @Override
    public String GetName() {
        return this.name;
    }
}
