package J02AfterClass.J00DataStructor.Quiz2;

public class Main 
{
    public static void main(String[] args) 
    {
        Menu m1 = new Burger("DeriBurger", 4500);
        Menu m2 = new Burger("Bulgogi",5500);
        Menu m3 = new Beverage("Sprite", 2500);
        Menu m4 = new Beverage("Coffee", 2500);
        
        Order o = new Order();
        o.AddList(m1);
        o.AddList(m2);
        o.AddList(m3);

        o.ShowAll();
        o.TotalPrice();
    }    
}
