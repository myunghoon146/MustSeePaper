package J02AfterClass.J00DataStructor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class MapPractice 
{
    public static void main(String[] args) 
    {
        Map<String, String> idPwMap = new HashMap<>();
        idPwMap.put("mtyc123", "6824Qwqw");
        idPwMap.put("kds", "1234");
        idPwMap.put("hiunsuk", "chs6824");
        idPwMap.put("myunghoon15","2953Qwqw@");
        idPwMap.put("Guest","5876");
        

        System.out.println(idPwMap);

        for(String key : idPwMap.keySet())
        {
            System.out.println("key: " +key);

        }

        // 검색하기. (특정 Key 값을 알면 특정 Value 값을 빠르게 검색!!!)
        System.out.println("Guest Password:" +idPwMap.get("Guest"));

        // Value들만 하나씩 출력하고 싶을 때 (키를 이용)
        for(String key : idPwMap.keySet())
        {
            System.out.println("Value: " + idPwMap.get(key));
        }


         for(String key : idPwMap.keySet())
        {
            System.out.println(key+ "=" +idPwMap.get(key));
        }

       // Map<String, List<클래스이름>> mapList;

       // 중복된 데이터를 넣어보자.
       idPwMap.put("Guest", "3850238502850");
       System.out.println("Duplicate Data Add: " +idPwMap);

       // 중복 체크( 특정 키 값이 존재하는지 확인, 데이터도 확인가능)

       boolean result = idPwMap.containsKey("Guest");
       System.out.println("Result: " +result);

       result = idPwMap.containsValue("1234");
       System.out.println("Result : " +result);

        
      
      List<String> idList = new ArrayList<>(idPwMap.keySet());
      // idPwMap를 keySet을 이용해서 Set으로 추출.
      // 이후 ArrayList 생성자에 의해서 리스트로 변환됨.
      // List, Set, Map -> Collections라는 상위 클래스가 있기에 가능


      // Map의 Key들을 모두 세트로 변환!!!!
      Set<String> idSet = idPwMap.keySet();

      //idList,idSet 출력
      System.out.println("List : " +idList);
      System.out.println("Set: " +idSet);
      
      // Map이 가지고 있는 Value 들을 모두 Set로 변환해보자.

      Set<String> psSet = new HashSet<>(idPwMap.values());  

      System.out.println(psSet); //자연스레 중복제거.
      // Map이 가지고 있는 Value들을 모두 List로 변환해보자.

      List<String> psList = new ArrayList<>(idPwMap.values());
      System.out.println(psList);
      
      // 간단 퀴즈. psList를 Set<String> temp로 넣고싶다면?
      Set<String> temp = new HashSet<>(psList);
      System.out.println(temp);

      // 간단 퀴즈. temp를 tempList라는 List에 넣기.
      //Set -> list 형변환 예제.
      List<String> tempList = new ArrayList<>(temp);
      System.out.println(tempList);

      // Entry를 이용해서 Key, Value 한번에 받아오자!!!
      for(Map.Entry<String,String>entry:idPwMap.entrySet())
      {
            System.out.println("ID : " +entry.getKey());
            System.out.println(", PS : " +entry.getValue());

      }
      // Map 어디서 쓸까?
      

   




        }

    }
