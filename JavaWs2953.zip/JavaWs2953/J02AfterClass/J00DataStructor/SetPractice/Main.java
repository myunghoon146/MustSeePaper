package J02AfterClass.J00DataStructor.SetPractice;
import java.util.Scanner;
import java.util.HashSet;
import java.util.Set;

public class Main 
{
    public static void main(String[] args){
  
    Set<String>id = new HashSet<>();

    Scanner sc = new Scanner(System.in);

    while(true)
    {
        String input = sc.nextLine();
        if(input=="Quit")
        {
            System.out.println("Duplicate");
            break;
        }
        else
        {
            System.out.println("Input Complete");

           if (id.add(input)) 
           {
                System.out.println("Input Complete");

           }
           
        }
    }
}
}
