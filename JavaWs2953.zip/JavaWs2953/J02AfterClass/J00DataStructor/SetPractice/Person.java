package J02AfterClass.J00DataStructor.SetPractice;

public class Person 
{
    String name;
    int residentNumber;
    
}
