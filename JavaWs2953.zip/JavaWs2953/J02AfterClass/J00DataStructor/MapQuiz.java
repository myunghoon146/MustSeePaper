package J02AfterClass.J00DataStructor;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class MapQuiz 
{
    public static void main(String[] args) 
    {
        
        Scanner sc = new Scanner(System.in);
        Map<String,Integer> pn = new HashMap<>();

        while(true)
        {
            String name;
            int phone;
            System.out.print("Name Input: " );
            name=sc.nextLine();
            System.out.print("Number Input: " );
            phone=sc.nextInt();
            sc.nextLine();
            if(name.equals("Quit"))
            {
                System.out.println("Already Exists.");
                break;

                
            }
            else
            {
                System.out.println("Save Complete");
            }


        }
    }    
}
