package J02AfterClass.J00DataStructor;

import java.util.ArrayList;
import java.util.List;

public class ListPractice 
{
    public static void main(String[] args) 
    {
        // 리스트 선언하기
        List<String> list = new ArrayList<>();

        List<String> otherList = new ArrayList<>();

        list.add("Java");
        otherList.add("Java");
        list.add("Python");
        otherList.add("C++");

        // 전부 출력하기
        System.out.println("ArrayList : "+ list);
        System.out.println("LinkedList : " +otherList);

        //Add는 인덱스로도 사용 가능
        list.add(1, "Javascript");
        otherList.add(2, "Java");

        System.out.println("ArrayList : " +list);
        System.out.println("LinkedList: " +otherList);


        // 요소 추출
        System.out.println("List[2] : " +list.get(2));
        System.out.println("OList[2] : " +otherList.get(2));

        System.out.println("C# ? : " + list.contains("C#"));
        System.out.println("C++ ?:"+otherList.contains("C++"));

        //제거 remove ->
        list.remove(0);
        list.remove(list.size()-1);
        list.remove("Javascript");

        System.out.println(list);
        System.out.println(list.remove("JavaScript"));
        System.out.println(list.remove("Python"));

        System.out.println(list.isEmpty());
        System.out.println(otherList.isEmpty());
        




    }    
}
