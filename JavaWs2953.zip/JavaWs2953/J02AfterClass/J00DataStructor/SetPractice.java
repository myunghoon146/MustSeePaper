package J02AfterClass.J00DataStructor;
import java.util.HashSet;
import java.util.Set;
public class SetPractice 
{
    public static void main(String[] args)
    {
        Set<String> fruits = new HashSet<>();

        fruits.add("Apple");
        fruits.add("Banana");
        fruits.add("Straw");
        fruits.add("Dragon");

        System.out.println(fruits);

        for(int i=0;i<100;i++)
        {
            fruits.add("Apple");
        }

        System.out.println(fruits);

        System.out.println("Apple: " +fruits.add("Apple"));
        System.out.println("Pineapple :" +fruits.add("Pineapple"));


        System.out.println("Dragone: ? " +fruits.contains("Dragon"));


        // Set 사이즈 측정
        System.out.println("Size : " +fruits.size());

        for(String s : fruits)
        {
            System.out.println(s);
        }


    }
}
