package J02AfterClass.J00DataStructor.ListPractice;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class AccessLog 
{
    private List<AccessRecord>log;  
    public AccessLog()
    {
        log = new ArrayList<>();
    }

    public void Enter(Person person)
    {
        LocalDateTime currentTime = LocalDateTime.now();
        AccessRecord newRecord = new AccessRecord(person, true, currentTime);

        log.add(newRecord);

    }   
    public void Exit(Person person)
    {

    }

    public void ShowLog()
    {
        if(log.isEmpty())
        {
            System.out.println("Empty");
        }

        else
        {
            int rowNum=1;
            for(AccessRecord line : log)
            {
                System.out.println(rowNum + " " +line);
            }
        }
    }

    public void CountLog()
    {
        System.out.println("Log Size : " +log.size());
    }



   
}
