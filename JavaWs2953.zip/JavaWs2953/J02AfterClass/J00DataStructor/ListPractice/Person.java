package J02AfterClass.J00DataStructor.ListPractice;

public class Person 
{
    private String name;
    
    public Person()
    {
        this.name="Guest";
    }

    public Person(String name)
    {
        this.name=name;
    }
    @Override
    public String toString()
    {
        return "Name:" + this.name;
        
    }

    public String GetName()
    {
        return this.name;
    }


}
