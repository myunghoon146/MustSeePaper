package J02AfterClass.J00DataStructor.ListPractice;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
public class AccessRecord 
{
    private Person person;
    private Boolean enterExit;
    private LocalDateTime time;  

    public AccessRecord(Person person, Boolean enterExit, LocalDateTime time)
    {
        this.person=person;
        this.enterExit=enterExit;
        this.time=time;
    }

    public Person GetPerson()
    {
        return this.person;
    }

    public LocalDateTime GetTime()
    {
        return this.time;
    }

   
    @Override
    public String toString() 
    {
        DateTimeFormatter f = DateTimeFormatter.ofPattern("yyyy-MM-dd, hh:mm:ss");
        String s = "[" + (enterExit ? "Enter" : "Exit") + "]";

        //삼항연산자 사용법 _> 조건식? 참일 경우 : 거짓일 경우

        s += person.GetName() + ">"+ time.format(f);

        return s;
    }
}

