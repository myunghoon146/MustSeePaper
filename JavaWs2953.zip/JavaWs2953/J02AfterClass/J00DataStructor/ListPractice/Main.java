package J02AfterClass.J00DataStructor.ListPractice;

public class Main 
{   public static void main(String[] args)
    {
    Person p1 = new Person();
    Person p2 = new Person("Marry");
    Person p3 = new Person("Korae");
    Person p4 = new Person("Ever");

    AccessLog getToWork= new AccessLog();
    try {
        getToWork.Enter(p1);
        Thread.sleep(1000);
        getToWork.Enter(p2);
        getToWork.Enter(p3);
        getToWork.Enter(p4);
        Thread.sleep(2000);
        getToWork.Exit(p1);
        getToWork.Exit(p2);
        getToWork.Enter(p1);
    } catch (InterruptedException e) {
        
        e.printStackTrace();
    }

    getToWork.ShowLog();
    









    }

}
