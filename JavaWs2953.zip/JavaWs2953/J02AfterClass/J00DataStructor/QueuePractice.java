package J02AfterClass.J00DataStructor;

import java.util.LinkedList;
import java.util.Queue;

public class QueuePractice 
{   public static void main(String[] args)
    {
    Queue<Integer> q = new LinkedList<>();
    q.add(10);
    q.add(20);
    q.add(30);
    q.add(40);
    q.add(50);

    System.out.println("Queue: " +q);

    // 하나씩 빼보기
    for(Integer i :q)
    {   
        System.out.println(i);
    }
    System.out.println("Poll :" +q.poll());
    System.out.println("Queue :" +q);

    System.out.println("Size : " +q.size());
    
    }        

    
}
