package J02AfterClass;

public class U {
    
    public static final String myName="ATS";
    public static int callCount=0;


    //내부 정적 클래스
    public static class E
    {
        // Enter 관련 메소드 모아두기

         public static void Enter()
    {
        callCount++;
        System.out.println("\n===========================\n");

    }

     public static void Enter2()
    {
        callCount++;
        System.out.println("\n---------------------\n");

    }
     public static void Enter3()
    {
        callCount++;
        System.out.println("\n~~~~~~~~~~~~~~~~~~~~~~~~\n");

    }
    public static void Ent()
    {
        callCount++;
        System.out.println("++++++++++++++++++++++++++++++");
    }

    


    }
    
    public static void Enter()
    {
        callCount++;
        System.out.println("\n===========================\n");

    }

    public static void P(int num)
    {
       
        System.out.println(num+"  ");
    }

    public static void P(String num)
    {
        System.out.println(num+"  ");
    }


    public static void P(double num)
    {
        System.out.println(num+"  ");
    }

    public static void P(int[] ary)
    {
        for(int i=0;i<ary.length;i++)
        {
            P(ary[i]);
        }
    }
    public static void PrintCallCount()
    {
        callCount++;
        System.out.println("Call Count : " +callCount);
    }
     
    


}
