package J02AfterClass.J12Class;

import java.util.Random;

public class ClassTest2 {
    // ✨ 2. 입력 받고 리턴은 없고(void)
    // Overload 다형성 기술 사용(똑같은 이름 다른 사용)
    public void LuckyNumber(int number)
    {
        Random rand = new Random();
        //입력받은 number를 nextINt에 넣어서 출력 값 범위지정.
        int randomNumber = rand.nextInt(number);
        System.out.println("Lucky Number : "+randomNumber);
    }
    // 오버로드 실습
    // 아래의 메소드들을 모두 PrintPlus로 만드세요
    // 1) 숫자 두개 전달받아서, 두개 더해서 출력
    public void PrintPlus(int n1, int n2){
        int result = n1+n2;
        System.out.println("result : " + result);
    }
    // 2) 숫자 세개 전달받아서, 세개 더해서 출력
    public void PrintPlus(int n1, int n2,int n3){
        int result = n1+n2+n3;
        System.out.println("result : " + result);
    }
    // 3) 숫자 네개 전달받아서, 네개 더해서 출력
    public void PrintPlus(int n1, int n2,int n3,int n4){
        int result = n1+n2+n3+n4;
        System.out.println("result : " + result);
    }
    // 4) 실수 두개 전달받아서, 두개 더해서 출력
    public void PrintPlus(double n1, double n2){
        double result = n1+n2;
        System.out.println("result : " + result);
    }
    // 5) 실수 세개 전달받아서, 두개 더해서 출력
    public void PrintPlus(double n1, double n2,double n3){
        double result = n1+n2+n3;
        System.out.println("result : " + result);
    }
    // 6) 실수 네개 전달받아서, 네개 더해서 출력
    public void PrintPlus(double n1, double n2,double n3,double n4){
        double result = n1+n2+n3+n4;
        System.out.println("result : " + result);
    }
}
