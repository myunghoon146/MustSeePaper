package J02AfterClass.J12Class;

import java.util.Random;

public class ClassTest4 {
    // ✨ 4. 입력,리턴 모두 있음
    // 1.1) 넘겨받은 숫자까지 랜덤값 만들어서 돌려주기(정수값으로)
    //      ReturnIntRandom(int ?)
    public int ReturnIntRandom(int size)
    {
        Random rand = new Random();
        int randomValue = rand.nextInt(size);
        return randomValue;
    }
    // 1.2) 넘겨받은 숫자까지 랜덤값 만들어서 돌려주기(실수값으로)
    //      ReturnDoubleRandom(int ?)
    public double ReturnDoubleRandom(int size)
    {
        Random rand = new Random();
        double randomValue = rand.nextDouble(size);
        return randomValue;
    }

    // 2) 넘겨받은 문자의 길이를 계산해서 돌려주기 ReturnStringLength
    public int ReturnStringLength(String s)
    {
        int len = s.length();
        return len;
    }
    // 3) 첫번째로 넘겨받은 숫자만큼 배열 만든 후, 두번재로 넘겨받은 
    //    숫자범위까지 랜덤하게 배열에 값을 채워서 리턴
    public int[] ReturnArray(int size,int randomSize)
    {
        int[] array = new int[size];
        //랜덤값은 여러분들이 알아서 알바 뽑으시고
        Random rand = new Random();
        for(int i=0;i<size;i++)
        {
            array[i] = rand.nextInt(randomSize);
        }
        return array;
    }   // 메인에서 이거 가지고 전체 요소들 다 출력해보세용.
}
