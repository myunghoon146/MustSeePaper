package J02AfterClass.J12Class;

import java.util.Random;

public class ClassTest1 {
    //입력X리턴X 메소드들 옮기기.
    // ✨ 1. 입력도 안받고 리턴도 없고
    public void Enter() // void : 리턴 없음.
    {
        System.out.println("\n==========================");
    }
    public void LuckyNumber()
    {
        Random rand = new Random();
        System.out.println("Lucky Number : " +rand.nextInt(10) );
    }
    // 1. Java에서 원주율을 출력하는 방법이 있습니다.
    // 인터넷에서 찾아서 원주율을 소수점 4자리까지 출력
    // PrintPI 메소드 구현하기
    public void PrintPI()
    {
        System.out.printf("%.4f\n",Math.PI);
    }
    // 2. 랜덤한 숫자를 45까지 6개를 뽑아서 출력하는
    // RandomMachine 메소드 구현하기
    public void RandomMachine()
    {
        Random rand = new Random();
        for(int i=0;i<6;i++)
        {
            System.out.print(rand.nextInt(45) + " ");
        }
        
    }
}
