package J02AfterClass.J12Class;
// 패키지 : 폴더.
// 왜쓰냐? 클래스 이름이 중복이 안됨. 패키지 다르면 중복 됨.
public class Main {
    
    public static void main(String[] args)
    {
        // ★ 퇴근실습
        // ClassTest2,3,4 객체 만들고 모든 메소드
        // 실행하기.
        // 클래스(파일) 4개를 새로 생성.
        // 입력X리턴X -> ClassTest1
        ClassTest1 alba1 = new ClassTest1();
        alba1.Enter();
        alba1.LuckyNumber();
        alba1.PrintPI();
        alba1.RandomMachine();

        // 입력O리턴X -> ClassTest2
        ClassTest2 alba2 = new ClassTest2();
        alba2.LuckyNumber(10);
        alba2.PrintPlus(1.1,2.2);
        alba2.PrintPlus(1.1,2.2,3.3);
        alba2.PrintPlus(1.1,2.2,3.3,4.4);
        alba2.PrintPlus(1,2);
        alba2.PrintPlus(1,2,3);
        alba2.PrintPlus(1,2,3,4);

        // 입력X리턴O -> ClassTest3
        ClassTest3 alba3 = new ClassTest3();
        String s = alba3.RandomFood();
        System.out.println(s);

        double pi = alba3.ReturnPI();
        System.out.println(pi);

        int x = alba3.ReturnRandom100();
        System.out.println(x);

        // 입력O리턴O -> ClassTest4
        ClassTest4 alba4 = new ClassTest4();
        int[] ary = alba4.ReturnArray(10, 20);
        for(int i : ary)
            System.out.print(i + " ");
        System.out.println();

        double k = alba4.ReturnDoubleRandom(20);
        System.out.println(k);

        int l = alba4.ReturnIntRandom(20);
        System.out.println(l);

        int slength = alba4.ReturnStringLength("HelloWorld");
        System.out.println(slength);

    }
}

