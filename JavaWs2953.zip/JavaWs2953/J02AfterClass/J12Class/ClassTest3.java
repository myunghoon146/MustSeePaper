package J02AfterClass.J12Class;

import java.util.Random;

public class ClassTest3 {
    // ✨ 3. 입력은 안받고 리턴은 있고
    // 1) 랜덤값 100까지 하나 돌려주기(int)
    public int ReturnRandom100()
    {
        Random rand = new Random();
        int result = rand.nextInt(100);
        return result;  //나를 불러준 곳에 result값 돌려주기
        // ★ return은 단 하나만 돌려주기 가능.
    }
    // 2) PI값 돌려주기 (PI는 무슨 자료형일까?)
    // 힌트. 마우스를 잘 올려보자.
    // ReturnPI
    public double ReturnPI()
    {
        return Math.PI;
    }

    // 3) 오늘 뭐 먹을지 돌려주기
    public String RandomFood()
    {
        String[] foods = new String[3];
        foods[0] = "Soon Dae Good";
        foods[1] = "Stir-fried Pork"; //제육볶음입니다 ^^;;
        foods[2] = "Money Gas";

        Random rand = new Random();        
        int choice = rand.nextInt(3); // 0~3전
        return foods[choice];
    }
}
