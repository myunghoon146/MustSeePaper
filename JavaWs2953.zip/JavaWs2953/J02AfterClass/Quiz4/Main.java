package J02AfterClass.Quiz4;

public class Main 
{
    public static void main(String[] args)
    {

    }    
}
