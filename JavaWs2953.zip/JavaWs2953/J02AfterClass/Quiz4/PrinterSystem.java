package J02AfterClass.Quiz4;
abstract public class PrinterSystem
{ 
    String documentName;
    int inkLevel;
    int paperCount;

    public PrinterSystem()
    {
        int inkLevel =100; 
        int paperCount = 10;
    }
   
    public abstract void printDocument()
    {
        ChangeDocument();
    }
    void ChangeDocument()
    {
        System.out.println("Document Name: " untitled);
    }
    void ChangeDocument(String changeName)
    {
        ChangeDocument(documentName);
    }
    void RefillInk()
    {
        int inklevel = 100; 
        System.out.println("Ink Refilled.");
    }
    void RefillPaper(int count)
    {
        paperCount += count;
        System.out.println("Paper Reload:" this.paperCount);

    }


}
