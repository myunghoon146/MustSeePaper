package J02AfterClass.Quiz4;

public class LaserPrinter
{
    
}
